/**
 * Copyright (c) 2016, Bongmi
 * All rights reserved
 * Author: wuyike@bongmi.com
 */

#import <UIKit/UIKit.h>

@interface UIStyle : NSObject

+ (UIButton *)createButtonWithTitle:(NSString *)title;

+ (UILabel *)createLabelWithTitle:(NSString *)title;

+ (UITextField *)createTextField;

+ (void)alertWithTitle:(NSString *)title
               message:(NSString *)message;

@end
