/**
 * Copyright (c) 2016, Bongmi
 * All rights reserved
 * Author: wuyike@bongmi.com
 */

#import <UIKit/UIKit.h>

@interface MainViewController : UIViewController

@end
