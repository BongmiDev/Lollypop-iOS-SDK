/**
 * Copyright (c) 2016, Bongmi
 * All rights reserved
 * Author: wuyike@bongmi.com
 */

#import "MainViewController.h"

#import "LoginViewController.h"
#import "RegisterViewController.h"
#import "UIStyle.h"

#import <Masonry/Masonry.h>

@interface MainViewController ()

@property (nonatomic, strong, readwrite) UIButton *registerBtn;

@property (nonatomic, strong, readwrite) UIButton *loginBtn;

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.registerBtn];
    [self.view addSubview:self.loginBtn];
    
    [self.loginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view.mas_left).offset(60);
        make.centerY.equalTo(self.view);
        make.size.mas_equalTo(CGSizeMake(100, 50));
    }];
    
    [self.registerBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.view.mas_right).offset(-60);
        make.centerY.equalTo(self.view);
        make.size.mas_equalTo(CGSizeMake(100, 50));
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - action
- (void)registerAction {
    UIViewController *registerVC = [[RegisterViewController alloc] init];
    [self.navigationController pushViewController:registerVC
                                         animated:YES];
}

- (void)loginAction {
    UIViewController *loginVC = [[LoginViewController alloc] init];
    [self.navigationController pushViewController:loginVC
                                         animated:YES];
}

#pragma mark - getter
- (UIButton *)registerBtn {
    if (_registerBtn == nil) {
        _registerBtn = [UIStyle createButtonWithTitle:@"Register"];
        [_registerBtn addTarget:self
                         action:@selector(registerAction)
               forControlEvents:UIControlEventTouchUpInside];
    }
    return _registerBtn;
}

- (UIButton *)loginBtn {
    if (_loginBtn == nil) {
        _loginBtn = [UIStyle createButtonWithTitle:@"Login"];
        [_loginBtn addTarget:self
                      action:@selector(loginAction)
            forControlEvents:UIControlEventTouchUpInside];
    }
    return _loginBtn;
}

@end
