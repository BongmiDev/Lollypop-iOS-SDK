/**
 * Copyright (c) 2016, Bongmi
 * All rights reserved
 * Author: wuyike@bongmi.com
 */

#import "BluetoothViewController.h"

#import "MainViewController.h"
#import "UIStyle.h"

#import <LollypopSDK/LollypopSDK.h>
#import <Masonry/Masonry.h>

@interface BluetoothViewController ()

@property (nonatomic, strong, readwrite) UIButton *conntectDeviceBtn;

@property (nonatomic, strong, readwrite) UIButton *disconntectDeviceBtn;

@property (nonatomic, strong, readwrite) UIButton *monitorTemperatureBtn;

@property (nonatomic, strong, readwrite) UIButton *deviceInfoBtn;

@property (nonatomic, strong, readwrite) UIButton *logoutBtn;

@end

@implementation BluetoothViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.conntectDeviceBtn];
    [self.view addSubview:self.disconntectDeviceBtn];
    [self.view addSubview:self.monitorTemperatureBtn];
    [self.view addSubview:self.deviceInfoBtn];
    [self.view addSubview:self.logoutBtn];
    
    [self.conntectDeviceBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.top.equalTo(self.view.mas_top).offset(100);
        make.size.mas_equalTo(CGSizeMake(200, 30));
    }];

    [self.disconntectDeviceBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.top.equalTo(self.conntectDeviceBtn.mas_bottom).offset(30);
        make.size.mas_equalTo(CGSizeMake(200, 30));
    }];

    [self.monitorTemperatureBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.top.equalTo(self.disconntectDeviceBtn.mas_bottom).offset(30);
        make.size.mas_equalTo(CGSizeMake(200, 30));
    }];

    [self.deviceInfoBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.top.equalTo(self.monitorTemperatureBtn.mas_bottom).offset(30);
        make.size.mas_equalTo(CGSizeMake(200, 30));
    }];
    
    [self.logoutBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.top.equalTo(self.deviceInfoBtn.mas_bottom).offset(30);
        make.size.mas_equalTo(CGSizeMake(200, 30));
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - event
- (void)conntectDeviceAction {
  [[LollypopSDK sharedInstance] conntectDeviceWithCallBack:^(id result,
                                                             NSError *error) {
      if (!error) {
          [UIStyle alertWithTitle:@"Conntect Success"
                          message:nil];
          NSLog(@"^ Conntect Device Success");
      } else {
          [UIStyle alertWithTitle:@"Conntect Fail"
                          message:error.description];
          NSLog(@"^ Conntect Device Fail:%@", error);
      }
  }];
}

- (void)disconntectDeviceAction {
  [[LollypopSDK sharedInstance] disconntectDeviceWithCallBack:^(id result, NSError *error) {
      if (!error) {
          [UIStyle alertWithTitle:@"Disconntect Success"
                          message:nil];
          NSLog(@"^ Disconntect Device Success");
      } else {
          [UIStyle alertWithTitle:@"Disconntect Fail"
                          message:error.description];
          NSLog(@"^ Disconntect Device Fail:%@", error);
      }
  }];
}

- (void)monitorTemperatureAction {
  [[LollypopSDK sharedInstance] getTemperatureWithTemperatureNotifier:^(LollypopTemperatureInfo *temperature,
                                                                        NSError *error) {
      if (!error) {
          dispatch_async(dispatch_get_main_queue(), ^{
              NSString *str = [NSString stringWithFormat:@"Temperature %ld\n Timestamp %@\n IsAccurateResult %d",
                               temperature.temperature,
                               temperature.timestamp,
                               temperature.isAccurateResult];
              [UIStyle alertWithTitle:@"Get temperature Success"
                              message:str];
              NSLog(@"^ Get temperature Success");
              NSLog(@"^ %@", str);
          });
      } else {
          [UIStyle alertWithTitle:@"Get temperature Fail"
                          message:error.description];
          NSLog(@"^ Get temperature Fail %@", error);
      }
  } callback:^(id result, NSError *error) {
      if (!error) {
          [UIStyle alertWithTitle:@"Monitor Temperature Success"
                          message:nil];
          NSLog(@"^ Monitor Temperature Success");
      } else {
          [UIStyle alertWithTitle:@"Monitor Temperature Fail"
                          message:error.description];
          NSLog(@"^ Monitor Temperature Fail %@", error);
      }
  }];
}

- (void)deviceInfoAction {
   [[LollypopSDK sharedInstance] getDeviceInfoWithCallBack:^(LollypopDeviceInfo *temperature,
                                                             NSError *error) {
       if (!error) {
           NSString *str = [NSString stringWithFormat:@"Device Id %@\n Battery Level %ld\n Software Version %@\n Hardware Version %@",
                            temperature.deviceId,
                            temperature.batteryLevel,
                            temperature.softwareVersion,
                            temperature.hardwareVersion];
           [UIStyle alertWithTitle:@"Get  Device Info Success"
                           message:str];
           NSLog(@"^ Get  Device Info Success");
           NSLog(@"^ %@", str);
       } else {
           [UIStyle alertWithTitle:@"Login fail"
                           message:error.description];
           NSLog(@"^ Get  Device Info fail %@", error);
       }
   }];
}

- (void)logoutAction {
    NSError *error = [[LollypopSDK sharedInstance] logout];
    if (!error) {
        MainViewController *vc = [[MainViewController alloc] init];
        [self presentViewController:vc
                           animated:YES
                         completion:nil];
    } else {
        [UIStyle alertWithTitle:@"Logout Fail"
                        message:error.description];
        NSLog(@"^ Logout Error %@", error);
    }
}

#pragma marlk - getter
- (UIButton *)conntectDeviceBtn {
    if (_conntectDeviceBtn == nil) {
        _conntectDeviceBtn = [UIStyle createButtonWithTitle:@"Conntect Device"];
        [_conntectDeviceBtn addTarget:self
                               action:@selector(conntectDeviceAction)
                     forControlEvents:UIControlEventTouchUpInside];
    }
    return _conntectDeviceBtn;
}

- (UIButton *)disconntectDeviceBtn {
    if (_disconntectDeviceBtn == nil) {
        _disconntectDeviceBtn = [UIStyle createButtonWithTitle:@"Disconntect Device"];
        [_disconntectDeviceBtn addTarget:self
                                  action:@selector(disconntectDeviceAction)
                        forControlEvents:UIControlEventTouchUpInside];
    }
    return _disconntectDeviceBtn;
}

- (UIButton *)monitorTemperatureBtn {
    if (_monitorTemperatureBtn == nil) {
        _monitorTemperatureBtn = [UIStyle createButtonWithTitle:@"Monitor Temperature"];
        [_monitorTemperatureBtn addTarget:self
                                   action:@selector(monitorTemperatureAction)
                         forControlEvents:UIControlEventTouchUpInside];
    }
    return _monitorTemperatureBtn;
}

- (UIButton *)deviceInfoBtn {
    if (_deviceInfoBtn == nil) {
        _deviceInfoBtn = [UIStyle createButtonWithTitle:@"Device Info"];
        [_deviceInfoBtn addTarget:self
                           action:@selector(deviceInfoAction)
                 forControlEvents:UIControlEventTouchUpInside];
    }
    return _deviceInfoBtn;
}

- (UIButton *)logoutBtn {
    if (_logoutBtn == nil) {
        _logoutBtn = [UIStyle createButtonWithTitle:@"Logout"];
        [_logoutBtn addTarget:self
                       action:@selector(logoutAction)
             forControlEvents:UIControlEventTouchUpInside];
    }
    return _logoutBtn;
}


@end
