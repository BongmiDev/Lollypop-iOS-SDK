/**
 * Copyright (c) 2016, Bongmi
 * All rights reserved
 * Author: wuyike@bongmi.com
 */

#import <Foundation/Foundation.h>

#import "LollypopTemperatureInfo.h"

#import "LollypopDeviceInfo.h"

typedef void(^LollypopCallback)(id result, NSError *error);

typedef void(^LollypopDeviceInfoNotifier)(LollypopDeviceInfo *temperature, NSError *error);

typedef void(^LollypopTemperatureNotifier)(LollypopTemperatureInfo *temperature, NSError *error);

@interface LollypopSDK : NSObject

+ (instancetype)sharedInstance;

+ (void)setApplicationId:(NSString *)applicationId;

- (void)conntectDeviceWithCallBack:(LollypopCallback)callback;

- (void)disconntectDeviceWithCallBack:(LollypopCallback)callback;

- (void)getDeviceInfoWithCallBack:(LollypopDeviceInfoNotifier)callback;

- (void)getTemperatureWithTemperatureNotifier:(LollypopTemperatureNotifier)temperatureNotifier
                                     callback:(LollypopCallback)callback;

- (void)registerWithPhoneNo:(NSString *)phoneNo
                   password:(NSString *)password
                   callback:(LollypopCallback)callback;

- (void)loginWithPhoneNo:(NSString *)phoneNo
                password:(NSString *)password
                callback:(LollypopCallback)callback;

- (NSError *)logout;

- (BOOL)isLogin;

@end
