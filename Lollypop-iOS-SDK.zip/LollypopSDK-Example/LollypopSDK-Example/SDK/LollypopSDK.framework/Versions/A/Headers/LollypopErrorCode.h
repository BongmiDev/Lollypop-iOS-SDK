/**
 * Copyright (c) 2016, Bongmi
 * All rights reserved
 * Author: wuyike@bongmi.com
 */

#import <Foundation/Foundation.h>

extern NSString *const kLollypopSDKErrorDomain;

typedef NS_ENUM(NSInteger, LollypopSDKErrorCode) {
    kLollypopSDKErrorCodeNotLogin = 1,      // 用户未登录
    kLollypopSDKErrorCodeAlreadyLogin = 2,  // 已有用户登录
    kLollypopSDKErrorCodeOther = 3          // 其他
};


