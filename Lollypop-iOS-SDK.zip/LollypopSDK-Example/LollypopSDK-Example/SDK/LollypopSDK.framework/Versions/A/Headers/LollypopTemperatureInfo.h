/**
 * Copyright (c) 2016, Bongmi
 * All rights reserved
 * Author: wuyike@bongmi.com
 */

#import <Foundation/Foundation.h>

@interface LollypopTemperatureInfo : NSObject

@property (nonatomic, assign, readonly) NSInteger temperature;

@property (nonatomic, strong, readonly) NSDate *timestamp;

@property (nonatomic, assign, readonly) BOOL isAccurateResult;

- (instancetype)initWithTemperature:(NSInteger)temperature
                          timestamp:(NSDate *)timestamp
                   isAccurateResult:(BOOL)isAccurateResult;

@end
