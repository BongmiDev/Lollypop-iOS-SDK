/**
 * Copyright (c) 2016, Bongmi
 * All rights reserved
 * Author: wuyike@bongmi.com
 */

#import <Foundation/Foundation.h>

@interface LollypopDeviceInfo : NSObject

@property (nonatomic, copy, readonly) NSString *deviceId;

@property (nonatomic, assign, readonly) NSUInteger batteryLevel;

@property (nonatomic, copy, readonly) NSString *softwareVersion;

@property (nonatomic, copy, readonly) NSString *hardwareVersion;

- (instancetype)initWithDeviceId:(NSString *)deviceId
                    batteryLevel:(NSUInteger)batteryLevel
                 softwareVersion:(NSString *)softwareVersion
                 hardwareVersion:(NSString *)hardwareVersion;

@end
