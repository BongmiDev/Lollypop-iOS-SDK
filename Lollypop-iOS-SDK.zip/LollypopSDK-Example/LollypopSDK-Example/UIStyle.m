/**
 * Copyright (c) 2016, Bongmi
 * All rights reserved
 * Author: wuyike@bongmi.com
 */

#import "UIStyle.h"

@implementation UIStyle

+ (UIButton *)createButtonWithTitle:(NSString *)title {
    UIButton* button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.titleLabel.font = [UIFont boldSystemFontOfSize:16.5];
    [button setTitleColor:[[UIColor blackColor] colorWithAlphaComponent:0.8]
                    forState:UIControlStateNormal];
    [button setTitle:title
            forState:UIControlStateNormal];
    [button.layer setBorderWidth:2];
    [button.layer setBorderColor:[UIColor blackColor].CGColor];
    [button setBackgroundImage:[self createImageWithColor:[UIColor grayColor]]
            forState:UIControlStateHighlighted];
    [button setBackgroundImage:[self createImageWithColor:[UIColor clearColor]]
            forState:UIControlStateNormal];
    return button;
}

+ (UILabel *)createLabelWithTitle:(NSString *)title {
    UILabel *label = [[UILabel alloc] init];
    label.text = title;
    label.textColor = [UIColor blackColor];
    label.font = [UIFont boldSystemFontOfSize:16.5];
    return label;
}

+ (UITextField *)createTextField {
    UITextField *textField = [[UITextField alloc] init];
    textField.borderStyle = UITextBorderStyleRoundedRect;
    textField.returnKeyType = UIReturnKeyNext;
    textField.clearButtonMode = UITextFieldViewModeWhileEditing;
    textField.layer.borderColor = [UIColor blackColor].CGColor;
    textField.layer.borderWidth = 2;
    return textField;
}

+ (void)alertWithTitle:(NSString *)title
               message:(NSString *)message {
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                        message:message
                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil, nil];
    [alertView show];
}
+ (UIImage *)createImageWithColor:(UIColor *)color {
    CGRect rect = CGRectMake(0.0f, 0.0f, 200.0f, 30.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return theImage;
}

@end
