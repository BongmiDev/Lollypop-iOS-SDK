/**
 * Copyright (c) 2016, Bongmi
 * All rights reserved
 * Author: wuyike@bongmi.com
 */

#import "RegisterViewController.h"

#import "BluetoothViewController.h"
#import "UIStyle.h"

#import <LollypopSDK/LollypopSDK.h>
#import <Masonry/Masonry.h>

@interface RegisterViewController ()

@property (nonatomic, strong, readwrite) UILabel *phoneNoLabel;

@property (nonatomic, strong, readwrite) UILabel *passwordLabel;

@property (nonatomic, strong, readwrite) UITextField *phoneNoTextField;

@property (nonatomic, strong, readwrite) UITextField *passwordTextField;

@property (nonatomic, strong, readwrite) UIButton *registerBtn;

@end

@implementation RegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.phoneNoLabel];
    [self.view addSubview:self.passwordLabel];
    [self.view addSubview:self.phoneNoTextField];
    [self.view addSubview:self.passwordTextField];
    [self.view addSubview:self.registerBtn];
    
    [self.phoneNoLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view.mas_top).offset(100);
        make.left.equalTo(self.view.mas_left).offset(20);
    }];
    
    [self.passwordLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.phoneNoLabel.mas_bottom).offset(30);
        make.left.equalTo(self.view.mas_left).offset(20);
    }];
    
    [self.phoneNoTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view.mas_top).offset(100);
        make.left.equalTo(self.phoneNoLabel.mas_right).offset(20);
        make.width.mas_offset(150);
    }];
    
    [self.passwordTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.phoneNoTextField.mas_bottom).offset(15);
        make.left.equalTo(self.passwordLabel.mas_right).offset(60);
        make.width.mas_offset(150);
    }];
    
    [self.registerBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(self.view);
        make.size.mas_equalTo(CGSizeMake(100, 50));
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - action
- (void)registerAction {
    [[LollypopSDK sharedInstance] registerWithPhoneNo:self.phoneNoTextField.text
                                             password:self.passwordTextField.text
                                             callback:^(id result, NSError *error) {
         if (error == nil) {
             BluetoothViewController *vc = [[BluetoothViewController alloc] init];
             [self presentViewController:vc
                                animated:YES
                              completion:nil];
         } else {
             [UIStyle alertWithTitle:@"Register fail"
                             message:error.description];
             NSLog(@"^ Register fail error : %@", error);
         }
    }];
}

#pragma mark - getter
- (UILabel *)phoneNoLabel {
    if (_phoneNoLabel == nil) {
        _phoneNoLabel = [UIStyle createLabelWithTitle:@"Phone Number"];
    }
    return _phoneNoLabel;
}

- (UILabel *)passwordLabel {
    if (_passwordLabel == nil) {
        _passwordLabel = [UIStyle createLabelWithTitle:@"Password"];
    }
    return _passwordLabel;
}

- (UITextField *)phoneNoTextField {
    if (_phoneNoTextField == nil) {
        _phoneNoTextField = [UIStyle createTextField];
        _phoneNoTextField.keyboardType = UIKeyboardTypePhonePad;
        _phoneNoTextField.secureTextEntry = NO;
    }
    return _phoneNoTextField;
}

- (UITextField *)passwordTextField {
    if (_passwordTextField == nil) {
        _passwordTextField = [UIStyle createTextField];
        _passwordTextField.keyboardType = UIKeyboardTypeDefault;
        _passwordTextField.secureTextEntry = YES;
    }
    return _passwordTextField;
}

- (UIButton *)registerBtn {
    if (_registerBtn == nil) {
        _registerBtn = [UIStyle createButtonWithTitle:@"Register"];
        [_registerBtn addTarget:self
                      action:@selector(registerAction)
            forControlEvents:UIControlEventTouchUpInside];
    }
    return _registerBtn;
}

@end
